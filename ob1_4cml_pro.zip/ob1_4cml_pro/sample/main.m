//
//  main.m
//  sample
//
//  Created by Angela on 2020-04-05.
//  Copyright © 2020 angela. All rights reserved.
//

#import <Foundation/Foundation.h>

int main(int argc, const char * argv[]) {
    
    int a = 0;
    int b = 0;
    
    if ( a == b ){
        printf("test line\n");}
    else { printf("not equal\n"); }
    
    
    
    // loops lesson
    
    int myc = 0;
    
    while (myc<2) {
        
        printf("good morning\n");
        printf("good afternoon\n");
        myc = myc +1;
        
    }
    
    
    return 0;
}
